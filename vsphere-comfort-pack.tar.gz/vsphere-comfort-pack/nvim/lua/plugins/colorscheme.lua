return {
  {
    "https://github.com/rebelot/kanagawa.nvim",
  },
  {
    "https://github.com/sainnhe/gruvbox-material",
    init = function ()
      vim.o.background = "dark"
      vim.g.gruvbox_material_transparent_background = 1
      vim.cmd.colorscheme "gruvbox-material"
    end,
  }
}
