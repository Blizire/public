return {
  "nvim-treesitter/nvim-treesitter",
  enabled = true,
  build = ":TSUpdate",
  config = function ()
    require 'nvim-treesitter.install'.compilers = { "gcc" }
    local configs = require("nvim-treesitter.configs")
    configs.setup({
        ensure_installed = { "c", "lua", "python", "rust"},
        sync_install = false,
        auto_install = true,
        highlight = {
           enable = true,
           additional_vim_regex_highlighting = false,
        },
        indent = { enable = true },
      })
  end
}
