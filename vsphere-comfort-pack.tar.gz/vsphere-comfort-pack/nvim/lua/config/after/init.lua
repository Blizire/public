require('config.after.lsp')
require('config.after.telescope')
