require('config.keymaps') -- core keymap settings
require('config.options') -- core vim settings
require('config.lazy') -- plugin manager
require('config.after') -- configurations after plugins are loaded
