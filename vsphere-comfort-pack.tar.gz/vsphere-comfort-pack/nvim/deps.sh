#!/usr/bin/env bash
# deps.sh - should install most dependencies needed for the config to install everything else

sudo snap install nvim --classic
sudo apt install git
sudo apt install build-essential
sudo apt install python3-pip
sudo apt install python3-venv
sudo apt install python3-protobuf
sudo apt install ripgrep
sudo apt install nodejs
sudo apt install npm
npm -g install pyright
