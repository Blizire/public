#!/usr/bin/env bash

# check if sxhkd is installed
if [[ "" == $(which sxhkd) ]]; then
    continue
else
  echo "sxhkd is not found, exitting!"
  exit
fi

# setup sxhkd ( simple x hotkey daemon )
if [[ -f ~/.config/sxhkd/sxhkdrc ]]; then
  echo "Warning existing config, stopping!"
  exit
else
  mkdir -vp ~/.config/sxhkd
  cat <<EOF > ~/.config/sxhkd/sxhkdrc
# open up common applications
ctrl + space ; {e, t, s, f, d}
{thunar, xfce4-terminal, xfce4-settings-manager, firefox-esr, discord}
EOF
  echo "Created sxhkdrc config @ ~/.config/sxhkd/sxhkdrc"
fi

# replace the keyboard caps lock with escape config
if [[ -f ~/.xinitrc ]]; then
  echo "Warning ~/.xinitrc already exists, quitting!"
  exit
else
  cat <<EOF > ~/.xinitrc
# open up common applications
ctrl + space ; {e, t, s, f, d}
  {thunar, xfce4-terminal, xfce4-settings-manager, firefox-esr, discord}
EOF
echo "Added ~/.xinitrc to remap caps lock to escape"
fi
